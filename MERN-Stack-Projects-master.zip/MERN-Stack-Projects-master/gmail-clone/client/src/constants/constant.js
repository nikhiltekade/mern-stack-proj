export const gmailLogo = 'https://ssl.gstatic.com/ui/v1/icons/mail/rfr/logo_gmail_lockup_default_1x_r5.png';
export const emptyInbox = 'https://miro.medium.com/max/1088/1*DhOnyEHovQZ31rH00-VUDw.png';

export const VIEWS = {
    inbox: 'inbox',
    starred: 'starred',
    sent: 'sent',
    drafts: 'drafts'
}